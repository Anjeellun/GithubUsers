package com.dicoding.githubusers.ui

import android.content.Intent
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.githubusers.data.Response.Users
import com.dicoding.githubusers.databinding.ActivityMainBinding
import com.dicoding.githubusers.ui.detail.UsersDetailActivity

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var viewModel: MainViewModel
    private lateinit var adapter: UsersAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = UsersAdapter()
        adapter.notifyDataSetChanged()
        viewModel = ViewModelProvider(this).get(MainViewModel::class.java)

        adapter.setOnItemClickCallback(object : UsersAdapter.OnItemClickCallback{
            override fun onItemClicked(data: Users) {
                Intent(this@MainActivity, UsersDetailActivity::class.java).also{
                    it.putExtra(UsersDetailActivity.EXTRA_USERNAME, data.login)
                    it.putExtra(UsersDetailActivity.EXTRA_ID, data.id)
                    startActivity(it)
                }
            }

        })

        binding.apply {
            recyclerviewUser.layoutManager = LinearLayoutManager(this@MainActivity)
            recyclerviewUser.setHasFixedSize(true)
            recyclerviewUser.adapter = adapter

            binding.btnSearch.setOnClickListener {
                searchUsers()
            }

            editTextQuery.setOnKeyListener { _, keyCode, event ->
                if (event.action == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_ENTER) {
                    searchUsers()
                    return@setOnKeyListener true
                }
                return@setOnKeyListener false
            }

        }

        viewModel.getSearchUsers().observe(this, {
            if (it!=null){
                adapter.setList(it)
                showLoading(false)
            }
        })

    }

    private fun searchUsers(){
        binding.apply {
            val query = editTextQuery.text.toString()
            if(query.isEmpty()) return
            showLoading(true)
            viewModel.setSearchUsers(query)
        }
    }

    private fun showLoading(state: Boolean){
        if(state){
            binding.progressbar.visibility = View.VISIBLE
        }else{
            binding.progressbar.visibility = View.GONE

        }
    }
}