package com.dicoding.githubusers.data.Response

data class UsersResponse(
    val items : ArrayList<Users>
)
